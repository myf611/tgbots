"""
Bot module for Telegram Medical Bot
"""
