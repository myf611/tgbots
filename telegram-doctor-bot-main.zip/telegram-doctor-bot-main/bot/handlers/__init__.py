"""
Handlers module for Telegram Medical Bot
"""
