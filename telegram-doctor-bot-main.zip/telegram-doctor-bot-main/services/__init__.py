"""
Services module for Telegram Medical Bot
"""
